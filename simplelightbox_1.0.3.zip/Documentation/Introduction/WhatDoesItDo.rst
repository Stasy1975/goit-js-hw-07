What does it do?
^^^^^^^^^^^^^^^^

The simplelightbox TYPO3 plugin brings the simplelightbox jquery plugin to TYPO3.

You can change every option that the lightbox have via TypoScript. See Installation for more info.