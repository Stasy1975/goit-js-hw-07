============================
Simplelightbox
============================

:Rendered:
      |today|

:Classification:
      simplelightbox

:Keywords:
      simplelightbox, modal, dialog, lightbox, touchfriendly, responsive, jquery

:Author:
      Andre Rinas

:Email:
      andreknieriem@gmail.com

:Language:
      en

.. toctree::

   Introduction/Index